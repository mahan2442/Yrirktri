import type { ModelDefinition } from "@/lib/models/catalog";

export type ChatMessage = { role: "system" | "user" | "assistant"; content: string };
export type NormalizedUsage = { inputTokens?: number; outputTokens?: number; estimated: boolean };
export type NormalizedResult = { text: string; usage: NormalizedUsage; providerRequestId?: string };
export interface ProviderAdapter {
  generate(model: ModelDefinition, messages: ChatMessage[], signal?: AbortSignal): Promise<NormalizedResult>;
}
