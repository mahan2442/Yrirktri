import Link from "next/link";

export default function PrivacyPage() {
  return <main className="app-shell min-h-screen px-5 py-12"><article className="surface mx-auto max-w-3xl rounded-3xl p-7 md:p-12">
    <Link href="/" className="text-sm text-violet-500">← بازگشت به Mahan AI</Link>
    <h1 className="mb-6 mt-5 text-3xl font-black">حریم خصوصی</h1>
    <div className="space-y-4 text-sm leading-8 muted">
      <p>این متن نمونه اولیه سیاست حریم خصوصی است و پیش از عرضه عمومی باید با رویه واقعی پردازش داده‌ها و الزامات قانونی محل فعالیت تطبیق داده شود.</p>
      <p>برای ارائه پاسخ، متن پیام‌ها ممکن است به ارائه‌دهنده مدل انتخاب‌شده ارسال شود. پیش از استفاده عملیاتی، شرایط نگهداری و پردازش داده‌های هر ارائه‌دهنده را بررسی کنید.</p>
      <p>کلیدهای API باید فقط در محیط امن سرور نگهداری شوند. اطلاعات حساس، رمزها و کلیدها نباید در پیام‌ها یا گزارش‌های پشتیبانی درج شوند.</p>
      <p>کاربران باید امکان درخواست حذف حساب و داده‌های مرتبط را طبق سیاست نهایی محصول داشته باشند؛ گردش‌کار حذف کامل در این نسخه هنوز پیاده‌سازی نشده است.</p>
    </div>
  </article></main>;
}
