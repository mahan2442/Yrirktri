import { z } from "zod";
import { getServerModel } from "@/lib/models/catalog";
import { adapterFor } from "@/lib/ai/adapters";
import type { ChatMessage } from "@/lib/ai/types";
import { enforceRateLimit } from "@/lib/security/rate-limit";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";
const schema = z.object({
  modelId: z.string().min(1).max(100),
  messages: z.array(z.object({
    role: z.enum(["user", "assistant", "system"]),
    content: z.string().max(16000)
  })).min(1).max(40).refine(items => items.reduce((sum, item) => sum + item.content.length, 0) <= 100000, "Conversation is too long")
});

export async function POST(request: Request) {
  const raw = await request.json().catch(() => null);
  const parsed = schema.safeParse(raw);
  if (!parsed.success) return Response.json({ error: "اطلاعات ارسالی معتبر نیست." }, { status: 400 });
  const { modelId, messages } = parsed.data;
  const lastUserMessage = [...messages].reverse().find(m => m.role === "user");
  if (!lastUserMessage || !lastUserMessage.content.trim()) return Response.json({ error: "پیام خالی است." }, { status: 400 });

  const model = getServerModel(modelId);
  if (!model) return Response.json({ error: "این مدل فعال نیست یا کلید API آن در Render تنظیم نشده است." }, { status: 503 });
  if (process.env.DEMO_MODE !== "false") {
    return Response.json({ error: "اتصال واقعی هوش مصنوعی هنوز فعال نیست. در Render مقدار DEMO_MODE=false و کلید API ارائه‌دهندهٔ مدل را تنظیم کنید." }, { status: 503 });
  }

  const forwarded = request.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "unknown";
  try {
    const rate = await enforceRateLimit(`guest-chat:${forwarded}`, Number(process.env.CHAT_RATE_LIMIT_PER_MINUTE || 8));
    if (!rate.success) return Response.json({ error: "درخواست‌های زیادی فرستاده‌اید؛ یک دقیقه دیگر تلاش کنید." }, { status: 429, headers: { "Retry-After": "60" } });
  } catch {
    // Anonymous chat stays available when Redis is not configured; use process-local throttling.
    const rate = localGuestLimit(forwarded);
    if (!rate) return Response.json({ error: "درخواست‌های زیادی فرستاده‌اید؛ یک دقیقه دیگر تلاش کنید." }, { status: 429 });
  }

  try {
    const adapter = adapterFor(model);
    const normalizedMessages = messages.map(m => ({ role: m.role, content: m.content })) as ChatMessage[];
    const result = await adapter.generate(model, normalizedMessages, AbortSignal.timeout(60000));
    return Response.json({ text: result.text, model: model.id, demo: false, usage: result.usage });
  } catch (error) {
    const message = error instanceof Error ? error.message : "UNKNOWN";
    console.error("ai_request_failed", { model: model.id, errorCode: message.split(":")[0] });
    const friendly = message === "PROVIDER_NOT_CONFIGURED" ? "کلید API این ارائه‌دهنده در تنظیمات Render وارد نشده است." :
      message.startsWith("PROVIDER_ERROR:429") ? "محدودیت درخواست ارائه‌دهنده؛ کمی بعد دوباره تلاش کنید." :
      message.startsWith("PROVIDER_ERROR:") ? "ارائه‌دهنده نتوانست درخواست را پردازش کند؛ تنظیمات API را بررسی کنید." :
      message.toLowerCase().includes("timeout") ? "زمان پاسخ‌گویی مدل تمام شد. دوباره تلاش کنید." : "در ارتباط با مدل خطایی رخ داد.";
    return Response.json({ error: friendly }, { status: 502 });
  }
}
const guestBuckets = new Map<string, { count: number; resetAt: number }>();
function localGuestLimit(key: string) {
  const now = Date.now();
  const current = guestBuckets.get(key);
  if (!current || current.resetAt <= now) { guestBuckets.set(key, { count: 1, resetAt: now + 60_000 }); return true; }
  current.count++;
  return current.count <= Number(process.env.CHAT_RATE_LIMIT_PER_MINUTE || 8);
}
